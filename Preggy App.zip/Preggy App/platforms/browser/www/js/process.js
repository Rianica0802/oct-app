let process = {
	menu:function(){
		let content = 
		<div className="page">
			<div className = "views">
				<div className = "view view-main theme-pink">
					<div className="navbar">
						<div className="navbar navbar-fixed">
							<div className="center">Pregnancy Calculator</div>
						</div>
					</div>
						<form class="list-block theme-pink">
  							<ul>
  								<li>
  									<br/><br/>
  								</li>
    							<li>
      								<div class="item-content">
        								<div class="item-inner">
          									<div class="item-title label label-big">Last menstral Period</div>
          										<div class="item-input">
            										<input type="date" placeholder="Date" id="y&m"/>
            									</div>
        								</div>
      								</div>
    							</li>
    							<li>
      								<a href="#" class="button button-big color-red" onClick={calculate}>Calculate</a>
      								<a href="#" class="button button-big color-red">Reset</a>
    							</li>
    						</ul>
    					</form>
    					<div className="page-content">
    						<form class="list-block theme-pink">
    							<ul id="listngmgabake">
   			    					<div className="content-block-title">Due Date, Conception Date Calculation Results:</div>
    								<li>
    									<div class="content-block-title">Estimated Facility Dates</div>	
    									<div class="item-content">
    									<div class="item-inner">
          										<div class="item-input">
            										<input type="text" placeholder="from" id="EFDfrom"/>
            									</div>
        								</div>
      								</div>
    								</li>
    								<li>
    								<div class="content-block-title">to</div>
    									<div class="item-content">
        								<div class="item-inner">
          										<div class="item-input">
            										<input type="text" placeholder="to" id="EFDto"/>
            									</div>
        								</div>
      								</div>
    								</li>
    								<li>
    									<div class="content-block-title">Estimated conception Date</div>	
    									<div class="item-content">
        								<div class="item-inner">
          										<div class="item-input">
            										<input type="text" placeholder="ECD" id="ECD"/>
            									</div>
        								</div>
      								</div>
    								</li>
    								<li>
    									<div class="content-block-title">First Trimester Ends (12 weeks)</div>	
    									<div class="item-content">
        								<div class="item-inner">
          										<div class="item-input">
            										<input type="text" placeholder="12 Weeks" id="TE12"/>
            									</div>
        								</div>
      								</div>
    								</li>
    								<li>
    									<div class="content-block-title">Second Trimester Ends (27 weeks)</div>	
    									<div class="item-content">
        								<div class="item-inner">
          										<div class="item-input">
            										<input type="text" placeholder="27 Weeks" id="TE27"/>
            									</div>
        								</div>
      								</div>
    								</li>
    								<li>
    									<div class="content-block-title">Estimated Due Date</div>	
    									<div class="item-content">
        								<div class="item-inner">
          										<div class="item-input">
            										<input type="text" placeholder="Due Date (40 Weeks)" id="dueDate"/>
            									</div>
        								</div>
      								</div>
    								</li>
    							</ul>
    						</form>
    					</div>
				</div>
			</div>
		</div>;
		ReactDOM.render(content,document.getElementById('root'));
	},
	loading:function(){
		let content = 
			<div className="portal-main">
				<div className="portal-container">
					<img className="portal" src="img/enter.jpg" onClick={process.menu}></img>
				</div>
			</div>;
		ReactDOM.render(content,document.getElementById('root'));
	}
}
process.menu();
process.loading();

function calculate() {
	var lastMens = document.getElementById('y&m').value;
	var days = 30;
	var month = ["January","February","March","April","May","June","July","August","September","October","November","December"];
	var months = 12;
	var year = ["2016","2017","2018","2019","2020"];
	var smart;
	var myday;
	var mymonth;
	var myyear;
	var monthIndex;
	var yearIndex;
	var Xspy;
	var Yspy;
	var Zspy;
	var dayCare;

	console.log(lastMens);

	for(var x = 1;x<year.length;x++){
		var yearIndex = x;
		for(var y = 1; y<=months;y++){
			Yspy = y;
			if(y < 10){
				y = "0"+ y;
			}
			for(var z = 1;z<=days;z++){
				Zspy = z;
				if(z < 10){
					z = "0" + z;
				}
				smart = year[x]+"-"+y+"-"+z;
				console.log(Zspy);
				if(smart === lastMens){
					console.log("HAHAHAHAHAHA");
					myday = z;
					mymonth = y;
					myyear = year[x];
					monthIndex = Yspy;
					Xspy = x;
					dayCare = Zspy;
				}
			}
		}
	}
	console.log(mymonth,myday,myyear,monthIndex);
	console.log(month[monthIndex-1],myday,myyear,dayCare);

	document.getElementById('EFDfrom').value = month[monthIndex-1] +" "+myday+" "+myyear;
    var efdto = Math.floor(myday) + 10;
    document.getElementById('EFDto').value = month[monthIndex-1] +" "+efdto+" "+myyear;
    var ecd = Math.floor(myday) + 4;
	document.getElementById('ECD').value = month[monthIndex-1] +" "+ecd+" "+myyear;

	for(var i = 0;i < 40;i++){
    	if(ecd === 30){
        	if(monthIndex === 12){
            	monthIndex = 0;
            	myyear = year[Xspy+1];
       		}
        		monthIndex += 1;
        		ecd = 0;
    	}else{
        	ecd+=1;
    	}
    }
    console.log(month[monthIndex],ecd);
	document.getElementById('TE12').value = month[monthIndex] +" "+ecd+" "+myyear;


	for(var i = 0;i < 106;i++){
    	if(ecd === 30){
        	if(monthIndex === 12){
            	monthIndex = 0;
            	myyear = year[Xspy+1];
       		}
        		monthIndex += 1;
        		ecd = 0;
    	}else{
        	ecd+=1;
    	}
    }
    console.log(month[monthIndex],ecd);
	document.getElementById('TE27').value = month[monthIndex] +" "+ecd+" "+myyear;

	for(var i = 0;i < 93;i++){
    	if(ecd === 30){
        	if(monthIndex === 12){
            	monthIndex = 0;
            	myyear = year[Xspy+1];
       		}
        		monthIndex += 1;
        		ecd = 0;
    	}else{
        	ecd+=1;
    	}
    }
    console.log(month[monthIndex],ecd);
	document.getElementById('dueDate').value = month[monthIndex] +" "+ecd+" "+myyear;

}