var month = ["January","February","March","April","May","June","July","August","September","October","November","December"];
var date = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
var year = [2017,2018,2019,2020,2021,2022,2023,2024,2025]
var facilityDate = "";
var Emonth;
var Edate;
var Eyear;
var conception;
var conc;
var flag = false;

function calculate(){
	console.log(document.getElementById('y&m').value);
	/*Emonth = document.getElementById('month-input').value;
	Edate = Math.floor(document.getElementById('date-input').value);
	Eyear = document.getElementById('year-input').value;
	facilityDate = Emonth + " " + Edate + " " + Eyear;
	document.getElementById('EFD').value = facilityDate;
	calcuEFD();
	con1();
	con2();
	con3();
	con4();*/
}

function con1() {
	for (var x = 0; x < month.length; x++){
		if(Emonth === month[x]){
			conc = month[x+3];
			conception = month[x+3] + " " + Edate + " " + Eyear;
			document.getElementById('conception').value = conception;		
		};
	}
}

function con2() {
	for (var x = 0; x < month.length; x++){
		if(conc === month[x]){
			conception = month[x+3] + " " + Edate + " " + Eyear;
			document.getElementById('first').value = conception;
		};
	}
}

function con3() {
	for (var x = 0; x < month.length; x++){
		if(conc === month[x]){
			conception = month[x+6] + " " + Edate + " " + Eyear;
			document.getElementById('second').value = conception;
		};
	}
}
function con4() {
	for (var x = 0; x < month.length; x++){
		if(conc === month[x]){
			var date = Edate + 5;
			conception = month[x+6] + " " + date + " " + Eyear;
			document.getElementById('due').value = conception;
		};
	}
}

function calcuEFD(){
	Edate += 14; 
	//console.log(Edate);
	facilityDate = Emonth + " " + Edate + " " + Eyear;
	document.getElementById('EFDto').value = facilityDate;
}

function reset(){
	flag = true;
	document.getElementById('date-input').innerText = "";
	document.getElementById('month-input').innerText = "";
	document.getElementById("year-input").innerHTML = "";
	document.getElementById("EFD").value = "";
	document.getElementById("EFDto").value = "";
	document.getElementById("conception").value = "";
	document.getElementById("first").value = "";
	document.getElementById("second").value = "";
	document.getElementById("due").value = "";		
	initialize();
}

function initialize() {
	var Monthparent = document.getElementById('month-input');
	var Dateparent = document.getElementById('date-input');
	var Yearparent  = document.getElementById('year-input');

	for (var i=0;i < 12;i++){
		var options = document.createElement('option');
		options.innerText = month[i];
		Monthparent.appendChild(options);
	}
	for (var i=0;i < 31;i++){
		var optionsD = document.createElement('option');
		optionsD.innerText = date[i];
		Dateparent.appendChild(optionsD);
	}
	for (var i=0;i < year.length;i++){
		var optionsD = document.createElement('option');
		optionsD.innerText = year[i];
		Yearparent.appendChild(optionsD);
	}
}
